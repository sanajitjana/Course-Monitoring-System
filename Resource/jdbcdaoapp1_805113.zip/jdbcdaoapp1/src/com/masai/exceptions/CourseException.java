package com.masai.exceptions;

public class CourseException extends Exception {
	
	public CourseException() {
		// TODO Auto-generated constructor stub
	}
	
	public CourseException(String message) {
		super(message);
	}
	

}
